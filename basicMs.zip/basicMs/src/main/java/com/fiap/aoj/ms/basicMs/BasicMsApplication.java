package com.fiap.aoj.ms.basicMs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasicMsApplication.class, args);
	}

}

